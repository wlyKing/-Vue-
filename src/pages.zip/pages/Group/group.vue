<template>
	<div>
		<child txt='小组'>
			<img src="../../assets/images/ic_actionbar_search_icon.png" alt="" class="leftImg">
			<img src="../../assets/images/ic_chat_green.png" alt="" class="rightImg">
		</child>
	</div>

</template>
<script>
	 import child from '../../components/child'
	  export default{
	  	components:{
          child
        }

	  }

</script>