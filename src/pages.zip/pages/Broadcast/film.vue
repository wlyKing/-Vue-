<template>
<div class="filmWarp">

	<flima txt1='美国队长3...' txt2='飞越老人院'  txt3='转角遇到爱'  txt4='美女与野兽'>
	</flima>
	<div class='mid'>
		<img src='../../assets/images/film0.jpg' >
		<h3>有“杨祐宁”的地方就有张孝全!这狗粮简直了</h3>
	</div>
		
<flima txt1='美国队长3...' txt2='飞越老人院'  txt3='转角遇到爱'  txt4='美女与野兽'>
	</flima>
	
	
</div>
</template>
<style>
	.filmWarp{height:750px}
	.top{background:#fff;width:100%;height:250px;border-top:15px solid #eee;border-bottom:15px solid #eee;}
	.top .text{height:58px;}
	.top h4{float:left;margin:15px;font-size:16px;color:#5c5c5c}
	.top .text p{margin:15px;color:#42c055;font-size:16px;float:right}
	.filmWarp .mid h3{margin:5px 15px;text-align:center;font-size:16px;font-weight: normal;}
	.filmWarp .mid img{width:100%}
	.top .pic img{height:130px;width:90px;float:left;display:block;position: absolute;}
	.top .pic .xin{height:15px;width:70px;position: absolute;top:155px;}
	.top .pic0{left:10px;position: relative;}
	.top .pic0 p{position: absolute;top:130px;font-size:15px;font-weight:bold}
	.top .pic0 span{position: absolute;top:155px;font-size:12px;left:70px}
	.top .pic1{left:120px}
	.top .pic2{left:230px}
	.top .pic3{left:340px}
</style>
<script>
	
	import flima from './flima'
	 	
	
	  export default{
	  	components:{
       		flima
        }
	  }


</script>