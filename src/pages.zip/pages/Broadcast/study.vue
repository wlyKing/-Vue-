<template>
<div>study</div>
</template>