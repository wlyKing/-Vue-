<template>
<div>
	<div class="top">
		<div class="text">
			<h4>影院热映</h4>
			<p>更多></p>
		</div>
		<div class='pic'>
			<div class='pic0'>
				<img src='../../assets/images/film01.jpg'>
				<p>{{txt1}}...</p>
				<img src='../../assets/images/3_03.jpg' class='xin'>
				<span>8.5</span>
			</div>		
			<div class='pic0 pic1'>
				<img src='../../assets/images/film02.jpg'>
				<p>{{txt2}}...</p>
				<img src='../../assets/images/3_03.jpg' class='xin'>
				<span>9.5</span>
			</div>

			<div class='pic0 pic2'>
				<img src='../../assets/images/film03.jpg'>
				<p>{{txt3}}...</p>
				<img src='../../assets/images/3_03.jpg' class='xin'>
				<span>7.5</span>
			</div>
			<div class='pic0 pic3'>
				<img src='../../assets/images/film04.jpg'>
				<p>{{txt4}}...</p>
				<img src='../../assets/images/3_03.jpg' class='xin'>
				<span>8.5</span>
			</div>
		</div>	

	</div>
</div>
</template>
<script>
	export default{
		props:['txt1','txt2','txt3','txt4']



	}


</script>
