<template>
<div>
	<flima></flima>

</div>
</template>
<script>
	
	import flima from './flima'
	 	
	
	  export default{
	  	components:{
       		flima
        }
	  }


</script>