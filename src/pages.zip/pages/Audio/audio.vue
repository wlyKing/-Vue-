<template>
	<body>
	<div class="audioWrap">
		<child txt='广播'>
			<img src="../../assets/images/ic_status_search_user.png" alt="" class="leftImg">
			<img src="../../assets/images/ic_chat_green.png" alt="" class="rightImg">
		</child>
		<div class="bac"><img src="../../assets/images/cit.jpg" alt=""></div>
		
		<div class="show" mark='0'>
			<div class="left">
			<img src="../../assets/images/cat.jpg" alt="" class="portrait">

			</div>
			<div class="rightw">
					<h4>小丸子</h4>
					<span>{{sumber}}关注</span>
					<p><a href="home">老白的警犬养老院：它是你的十年，你是它的一辈子[泪]】杭州民警白雁在山上为退役警犬建了一个“警犬养老院”，目前共有16条警犬生活在那里，年龄都在10岁以上。他亲自照料这些警犬，全年无休。“养老院”里</a></p>
					<div class="like">
						<img src="../../assets/images/ic_like_full.png" alt="" class="full">
						<p @click='nu'>{{num}}</p>
						<img src="../../assets/images/ic_feedback_comment.png" alt="" class="comment" >
						<span @click='su'>{{sun}}</span>
						<button :class={activ:bol} @click='fn'>{{tex}}</button>
					</div>			
			</div>
		</div>	

		<div class="show hiid">
			<div class="left">
			<img src="../../assets/images/tat.jpg" alt="" class="portrait">

			</div>
			<div class="rightw">
					<h4>小丸子</h4>
					<span>{{number}}关注</span>
					<p><a href="home">【雪媚娘】七夕最佳甜品，有雪媚娘在，单身狗也能愉快的度过了！做了三种口味，抹茶红豆、桃子、芒果。皮糯糯的，奶油馅像冰淇淋一样入口即化，一咬果粒迸出汁[喵喵] #一日一食一记##厨房的诱惑# ​</a></p>
					<div class="like">
						<img src="../../assets/images/ic_like_full.png" alt="" class="full">
						<p @click='nu'>{{te}}</p>
						<img src="../../assets/images/ic_feedback_comment.png" alt="" class="comment" >
						<span @click='su'>{{ke}}</span>
						<button :class={activ:bol} @click='fn'>{{tex}}</button>
					</div>			
			</div>
		</div>	
	</div>
	</body>
</template>
<style>
   
	body{width:100%;background:#f7f7f7}
	.audioWrap{height:850px;width:100%;}
	.bac img{width:100%}
	.show{width:90%;background:#fff;height:300px;margin:0 auto;border-radius:8px;box-shadow:0 0 10px #ccc}
	.hiid{margin-top:20px}
	.show .left{width:25%;float:left}
	.show .left .portrait{width:55px;height:55px;border-radius:50%;margin:20px}
	.show .rightw{width:75%;float:right;}
	.show .rightw h4{margin:30px 0 0 10px}
	.show .rightw span{font-size:12px;color:#acacac;margin-left:10px}
	.show .rightw p{font-weight: normal;margin:10px 20px 0 5px;line-height:22px}
	.show .rightw .like {position: relative;height:20px;width:75px;}
	.show .rightw .like .full{width:18px; padding-rightw:20px;position:absolute;position:absolute;top:20px;left:4px}
	.show .rightw .like .comment{width:22px;position:absolute;top:22px;left:60px;}
	.show .rightw .like p{position:absolute;top:10px;left:20px;color:#acacac;font-size:12px}
	.show .rightw .like span{position:absolute;top:23px;left:76px;color:#acacac;font-size:12px}
	.show .rightw .like button{background:#42c055;color:#fff;width:70px;height:25px;line-height:25px;position:absolute;top:-200px;left:160px; border:0px none}
	.show .rightw .like .activ{background:#999}
	
</style>
<script>
	 import child from '../../components/child'
	  export default{
	  	components:{
          child
        },
        props:['mark'],
        data:function(){
        	return{
        		bol:false,
        		num:50,
        		sun:29,
        		tex:'关注',
        		ke:0,
        		te:0,
        		number:55324,
        		sumber:4428,
        	

        	}
        },
         methods:{
         	nu:function(){
         		this.num++
         		this.te++
         		  						
         	},
         	su:function(){

         		this.sun++

				this.ke++

         	},
        	fn:function(){
        	if(this.bol!=true){
        		this.bol=true;
        		this.tex='已关注'
        		this.number++
        		this.sumber++
        	}else if(this.bol!=false){
        		this.tex='关注'
        		this.bol=false;
        		this.number--;
        		this.sumber--

        	}
        	}
        }	

	  }

</script>